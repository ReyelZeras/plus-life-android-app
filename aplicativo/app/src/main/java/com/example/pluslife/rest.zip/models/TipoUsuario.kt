package com.example.pluslife.models

data class TipoUsuario(
    val id: Int,
    val tipo: String,
)
