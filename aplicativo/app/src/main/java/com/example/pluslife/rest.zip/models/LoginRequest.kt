package com.example.pluslife.models

data class LoginRequest(
    val email: String,
    val senha: String,
)
